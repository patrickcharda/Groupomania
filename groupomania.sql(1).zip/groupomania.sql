-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2021 at 01:43 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `groupomania`
--
CREATE DATABASE IF NOT EXISTS `groupomania` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `groupomania`;

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `content` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `post_id`, `user_id`, `created_at`, `content`) VALUES
(102, 138, 8, '2021-02-24 16:11:31', 'super'),
(112, 145, 34, '2021-02-24 19:12:03', 'ioda'),
(113, 143, 34, '2021-02-24 19:17:08', 'beauté'),
(114, 146, 8, '2021-02-24 19:39:48', 'coucher de soleil');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `content` varchar(255) NOT NULL,
  `image_url` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `user_id`, `created_at`, `content`, `image_url`) VALUES
(138, 34, '2021-02-24 16:10:06', 'fruit décoratif!', '20210224_182412.jpg1614189691667.jpeg'),
(143, 8, '2021-02-24 19:01:05', 'nature is beautiful', '20210224_182602.jpg1614189665090.jpeg'),
(144, 8, '2021-02-24 19:02:23', 'Alienoween', '20210224_183253.jpg1614189743318.jpeg'),
(145, 8, '2021-02-24 19:02:55', 'au large', '20210224_182245.jpg1614189775466.jpeg'),
(146, 34, '2021-02-24 19:07:53', 'beau soleil', '20210224_182858.jpg1614190073646.jpeg'),
(149, 8, '2021-02-25 16:34:39', 'Welcome ', 'icon-above-font.png1614267279896.png'),
(154, 8, '2021-02-26 09:12:19', '', 'frontVSback.jpg1614327139334.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `firstname`, `lastname`, `role`) VALUES
(8, 'fanny@free.fr', '$2b$10$uoS5Kf2OMc.Wymk4qHRZ8O5r0rZ6ZZ9ZAYTBRgPSsv/hugJdHOAN6', 'fanny', 'dupond', 'admin'),
(28, 'mike@free.fr', '$2b$10$1aC.CS/5ubr7xCIBV7X.A.mHqYV2UvDDo61Bpb3dmBv/JoduE74Ke', 'Mickael', 'London', 'user'),
(34, 'martin@free.fr', '$2b$10$lOjQEIeR2U66Ytb/MuSu2uhusgbLyDEUdstfW6QZh.G1N06RD9/1O', 'Martin', 'Pecheur', 'user'),
(35, 'paulette@free.fr', '$2b$10$bAyOlVSltb.hD5y1GfTjoeVMDRa71rYTsseQ4Io/yceNuEAniyHGC', 'Paulette', 'Pecheur', 'user'),
(37, 'germaine@free.fr', '$2b$10$uIqxOui44y1lSHsgGnS4.OqAbOddl6Qbaa3HZpWQoXTYK1QChhcOO', 'Germaine', 'Duvert', 'user'),
(40, 'louisa@free.fr', '$2b$10$2NK7hRnGU.WqJslOc099GO5juh2s.yTGVlA2cQEQfOw29LCnUgJYW', 'louisa', 'mona', 'user'),
(44, 'gerald@free.fr', '$2b$10$QK93vx3Sh//u/Ic1qFQYr.ODpkhZc.xw/6wxSmw37McVq81HBhNQi', 'Gérald', 'Ohin', 'user'),
(53, 'fatia@free.fr', '$2b$10$c.pfuo/DhfnHfEWpGp7b/udYIhg.rgWJyjDBLPaNeCfvUfluzu2/q', 'Fatia', 'Radia', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_index` (`user_id`) USING BTREE,
  ADD KEY `post_index` (`post_id`) USING BTREE;

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_index` (`user_id`) USING BTREE;

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_index` (`email`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `fk_post` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `user_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
