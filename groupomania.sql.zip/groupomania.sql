-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2021 at 10:06 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `groupomania`
--
CREATE DATABASE IF NOT EXISTS `groupomania` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `groupomania`;

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `content` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `post_id`, `user_id`, `created_at`, `content`) VALUES
(55, 89, 34, '2021-02-22 10:31:08', 'top chef'),
(58, 89, 34, '2021-02-22 12:24:32', 'machin'),
(77, 81, 28, '2021-02-22 16:06:18', 'dgestr'),
(79, 81, 8, '2021-02-22 16:07:49', 'génial'),
(80, 81, 8, '2021-02-22 16:08:10', 'bye'),
(81, 81, 8, '2021-02-22 16:09:53', 'rfqerf'),
(85, 89, 8, '2021-02-22 16:23:00', 'bon!'),
(92, 120, 42, '2021-02-23 11:05:32', 'super');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `content` varchar(255) NOT NULL,
  `image_url` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `user_id`, `created_at`, `content`, `image_url`) VALUES
(81, 34, '2021-02-20 11:43:54', '81 dqfqdf', 'langue.png1613861232240.png'),
(89, 34, '2021-02-20 19:04:41', '89 sdfgdsfq', 'tartare1.jpg1613986183850.jpeg'),
(117, 8, '2021-02-22 22:40:56', '', 'amora-sauce-barbecue.jpg1614030056008.jpeg'),
(118, 8, '2021-02-22 23:54:34', 'vla', 'langue.png1614034474001.png'),
(119, 8, '2021-02-23 00:02:24', '', 'langue.png1614034944808.png'),
(120, 34, '2021-02-23 00:15:50', 'qrgfaeraeg', 'tartare1.jpg1614035750652.jpeg'),
(124, 8, '2021-02-23 16:52:36', 'sdfgdfg', 'Canne-de-Combat.jpg1614095556198.jpeg'),
(125, 8, '2021-02-23 19:16:13', '', 'langue.png1614104173592.png'),
(126, 8, '2021-02-23 19:16:38', '', 'comedia.gif1614104198307.gif');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `firstname`, `lastname`, `role`) VALUES
(8, 'fanny@free.fr', '$2b$10$uoS5Kf2OMc.Wymk4qHRZ8O5r0rZ6ZZ9ZAYTBRgPSsv/hugJdHOAN6', 'fanny', 'dupond', 'admin'),
(28, 'mike@free.fr', '$2b$10$1aC.CS/5ubr7xCIBV7X.A.mHqYV2UvDDo61Bpb3dmBv/JoduE74Ke', 'Mickael', 'London', 'user'),
(34, 'martin@free.fr', '$2b$10$lOjQEIeR2U66Ytb/MuSu2uhusgbLyDEUdstfW6QZh.G1N06RD9/1O', 'Martin', 'Pecheur', 'user'),
(35, 'paulette@free.fr', '$2b$10$bAyOlVSltb.hD5y1GfTjoeVMDRa71rYTsseQ4Io/yceNuEAniyHGC', 'Paulette', 'Pecheur', 'user'),
(37, 'germaine@free.fr', '$2b$10$uIqxOui44y1lSHsgGnS4.OqAbOddl6Qbaa3HZpWQoXTYK1QChhcOO', 'Germaine', 'Duvert', 'user'),
(40, 'louisa@free.fr', '$2b$10$2NK7hRnGU.WqJslOc099GO5juh2s.yTGVlA2cQEQfOw29LCnUgJYW', 'louisa', 'mona', 'user'),
(42, 'dede@free.fr', '$2b$10$N.g2kBJmVP0Ij5lYLBeCFuclqaPq/E0kIKYmyLoGReQtT2tieMLmG', 'andré', 'durand', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_index` (`user_id`) USING BTREE,
  ADD KEY `post_index` (`post_id`) USING BTREE;

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_index` (`user_id`) USING BTREE;

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_index` (`email`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `fk_post` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `user_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
